class GenericResponse {
  constructor() {
    this.success = false;
    this.error = {};
  }
}
module.exports = GenericResponse;
