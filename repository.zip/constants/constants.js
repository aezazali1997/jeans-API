const DB=`product`;
module.exports= {
Database:{
host:`mongodb://localhost:27017/${DB}`
}
}