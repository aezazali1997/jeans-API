const Product=require('./model/product');
const connectDB = require("./config/db");
connectDB();
const PRODUCT = {
  name:'blue jeans',
  description:'it is made of pure fabrics',
  image:'',
  length:28,
  color:'white',
  style:'narrow bottom'
}
const importData = async ()=>{
  try {
    await Product.create(PRODUCT);
    console.log("products created");

  } catch (error) {
    console.log(error);
  }
}
importData(); 